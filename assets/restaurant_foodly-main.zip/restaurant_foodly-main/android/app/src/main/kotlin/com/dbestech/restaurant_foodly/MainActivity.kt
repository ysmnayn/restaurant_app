package com.dbestech.restaurant_foodly

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
